"""PEESTOCK — Screener API (pattern scan results)."""

import json
from typing import Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.schemas import PatternOut
from app.auth import get_current_user

router = APIRouter(prefix="/api/screener", tags=["screener"])


@router.get("/patterns", response_model=list[PatternOut])
async def list_patterns(
    pattern_type: Optional[str] = Query(None),
    status: Optional[str] = Query("forming"),
    timeframe: Optional[str] = Query("D"),
    limit: int = Query(50, le=200),
    db: AsyncSession = Depends(get_db),
    _user=Depends(get_current_user),
):
    """List detected chart patterns, capped to the single most impactful
    pattern per instrument (impact = projected % move from latest close to
    target price; falls back to confidence when no target price is set)."""
    filters = []
    params: dict = {"limit": limit}
    if pattern_type:
        filters.append("dp.pattern_type = :pattern_type")
        params["pattern_type"] = pattern_type
    if status:
        filters.append("dp.status = :status")
        params["status"] = status
    if timeframe:
        filters.append("dp.timeframe = :timeframe")
        params["timeframe"] = timeframe
    where_clause = f"WHERE {' AND '.join(filters)}" if filters else ""

    query = f"""
        WITH latest_close AS (
            SELECT instrument_id, close,
                   ROW_NUMBER() OVER (PARTITION BY instrument_id ORDER BY time DESC) AS rn
            FROM ohlcv_eod
        ),
        ranked_patterns AS (
            SELECT
                dp.id, dp.timeframe, dp.pattern_type, dp.status, dp.confidence,
                dp.detection_time, dp.key_points, dp.target_price, dp.stop_loss,
                dp.image_url, i.symbol AS symbol,
                ROW_NUMBER() OVER (
                    PARTITION BY dp.instrument_id
                    ORDER BY
                        CASE WHEN dp.target_price IS NULL OR lc.close IS NULL OR lc.close = 0
                             THEN 0
                             ELSE ABS(dp.target_price - lc.close) / lc.close
                        END DESC,
                        dp.confidence DESC,
                        dp.detection_time DESC
                ) AS rn
            FROM detected_patterns dp
            JOIN instruments i ON i.id = dp.instrument_id
            LEFT JOIN latest_close lc ON lc.instrument_id = dp.instrument_id AND lc.rn = 1
            {where_clause}
        )
        SELECT * FROM ranked_patterns
        WHERE rn = 1
        ORDER BY detection_time DESC
        LIMIT :limit
    """
    result = await db.execute(text(query), params)
    rows = result.mappings().all()

    patterns = []
    for row in rows:
        key_points = row["key_points"]
        if isinstance(key_points, str):
            key_points = json.loads(key_points)
        patterns.append(PatternOut(
            id=row["id"],
            symbol=row["symbol"],
            timeframe=row["timeframe"],
            pattern_type=row["pattern_type"],
            status=row["status"],
            confidence=float(row["confidence"]) if row["confidence"] is not None else None,
            detection_time=row["detection_time"],
            key_points=key_points,
            target_price=float(row["target_price"]) if row["target_price"] is not None else None,
            stop_loss=float(row["stop_loss"]) if row["stop_loss"] is not None else None,
            image_url=row["image_url"],
        ))
    return patterns


@router.get("/patterns/{pattern_id}", response_model=PatternOut)
async def get_pattern(
    pattern_id: int,
    db: AsyncSession = Depends(get_db),
    _user=Depends(get_current_user),
):
    """Fetch a single detected pattern by id (used to overlay it on the chart)."""
    from fastapi import HTTPException

    result = await db.execute(
        text(
            "SELECT dp.id, dp.timeframe, dp.pattern_type, dp.status, dp.confidence, "
            "dp.detection_time, dp.key_points, dp.target_price, dp.stop_loss, "
            "dp.image_url, i.symbol AS symbol "
            "FROM detected_patterns dp JOIN instruments i ON i.id = dp.instrument_id "
            "WHERE dp.id = :id"
        ),
        {"id": pattern_id},
    )
    row = result.mappings().first()
    if not row:
        raise HTTPException(status_code=404, detail="Pattern not found")

    key_points = row["key_points"]
    if isinstance(key_points, str):
        key_points = json.loads(key_points)

    return PatternOut(
        id=row["id"],
        symbol=row["symbol"],
        timeframe=row["timeframe"],
        pattern_type=row["pattern_type"],
        status=row["status"],
        confidence=float(row["confidence"]) if row["confidence"] is not None else None,
        detection_time=row["detection_time"],
        key_points=key_points,
        target_price=float(row["target_price"]) if row["target_price"] is not None else None,
        stop_loss=float(row["stop_loss"]) if row["stop_loss"] is not None else None,
        image_url=row["image_url"],
    )


@router.post("/trigger-scan")
async def trigger_scan(db: AsyncSession = Depends(get_db), _user=Depends(get_current_user)):
    """Manually trigger pattern and trendline detection scans."""
    from app.workers.tasks_eod import run_pattern_scan, run_trendline_scan
    
    # We use .delay() for Celery, but here we can try to run it directly if Celery isn't setup
    # or just return a message saying it's queued.
    try:
        run_pattern_scan.delay()
        run_trendline_scan.delay()
        return {"status": "success", "message": "Scans triggered in background"}
    except Exception as e:
        # If celery is not running, run synchronously (might be slow but works for dev)
        run_pattern_scan()
        run_trendline_scan()
        return {"status": "success", "message": "Scans completed synchronously"}

