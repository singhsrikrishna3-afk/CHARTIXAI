"""PEESTOCK — Custom Scanners CRUD API."""

from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select, desc
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models import CustomScanner, User
from app.schemas import ScannerCreate, ScannerOut
from app.auth import get_current_user

router = APIRouter(prefix="/api/scanners", tags=["scanners"])


from app.schemas import ScannerOut
import uuid
import json
from datetime import datetime

SYSTEM_SCANS = [
    ("Golden Crossover (Long Term Bullish)", "The 50-day Simple Moving Average crosses above the 200-day Simple Moving Average.", '[{"indicator": "sma", "params": {"period": 50}, "operator": "crosses_above", "compare_to": {"indicator": "sma", "params": {"period": 200}}}]', '00000000-0000-4000-8000-000000000001'),
    ("Death Crossover (Long Term Bearish)", "The 50-day Simple Moving Average crosses below the 200-day Simple Moving Average.", '[{"indicator": "sma", "params": {"period": 50}, "operator": "crosses_below", "compare_to": {"indicator": "sma", "params": {"period": 200}}}]', '00000000-0000-4000-8000-000000000002'),
    ("RSI Oversold (Potential Reversal)", "RSI (14) has dropped below 30, signaling an oversold condition.", '[{"indicator": "rsi", "params": {"period": 14}, "operator": "lt", "value": 30}]', '00000000-0000-4000-8000-000000000003'),
    ("RSI Overbought (Potential Pullback)", "RSI (14) has risen above 70, signaling an overbought condition.", '[{"indicator": "rsi", "params": {"period": 14}, "operator": "gt", "value": 70}]', '00000000-0000-4000-8000-000000000004'),
    ("MACD Bullish Crossover", "The MACD line has crossed above its Signal line.", '[{"indicator": "macd", "params": {"fast": 12, "slow": 26, "signal": 9, "component": "macd"}, "operator": "crosses_above", "compare_to": {"indicator": "macd", "params": {"fast": 12, "slow": 26, "signal": 9, "component": "signal"}}}]', '00000000-0000-4000-8000-000000000005'),
    ("Bollinger Band Squeeze Breakout", "Bollinger Bands have tightened (Bandwidth < 0.05), indicating a period of extremely low volatility.", '[{"indicator": "bbands", "params": {"period": 20, "std_dev": 2.0, "component": "bandwidth"}, "operator": "lt", "value": 0.05}]', '00000000-0000-4000-8000-000000000006'),
    ("Supertrend Buy Signal", "Price has crossed above the Supertrend line, giving a fresh buy signal.", '[{"indicator": "supertrend", "params": {"period": 10, "multiplier": 3.0, "component": "trend"}, "operator": "eq", "value": 1}]', '00000000-0000-4000-8000-000000000007'),
    ("ADX Strong Trend Formation", "ADX (14) is greater than 25, confirming the presence of a strong underlying trend.", '[{"indicator": "adx", "params": {"period": 14, "component": "adx"}, "operator": "gt", "value": 25}]', '00000000-0000-4000-8000-000000000008'),
    ("NR7 (Narrow Range 7)", "The stock has formed its narrowest trading range of the last 7 days.", '[{"indicator": "nr7", "params": {}, "operator": "eq", "value": 1}]', '00000000-0000-4000-8000-000000000009'),
    ("Inside Bar Breakout Setup", "The current daily candle is completely contained within the previous day's high-low range.", '[{"indicator": "inside_bar", "params": {}, "operator": "eq", "value": 1}]', '00000000-0000-4000-8000-000000000010'),
    ("Bullish Engulfing Pattern", "A large bullish candle has completely engulfed the previous bearish candle.", '[{"indicator": "engulfing", "params": {}, "operator": "eq", "value": 1}]', '00000000-0000-4000-8000-000000000011'),
    ("Hammer Candlestick", "A hammer candlestick has formed showing aggressive buying at the lows.", '[{"indicator": "hammer", "params": {}, "operator": "eq", "value": 1}]', '00000000-0000-4000-8000-000000000012'),
    ("Strong Gap Up Open", "The stock has gapped up by at least 1% compared to yesterday's high.", '[{"indicator": "gap_up", "params": {"min_percent": 1.0}, "operator": "eq", "value": 1}]', '00000000-0000-4000-8000-000000000013')
]

@router.get("/", response_model=list[ScannerOut])
async def list_scanners(
    include_public: bool = Query(True),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """List user's scanners + optional public scanners."""
    if include_public:
        q = select(CustomScanner).where(
            (CustomScanner.user_id == user.id) | (CustomScanner.is_public == True)
        )
    else:
        q = select(CustomScanner).where(CustomScanner.user_id == user.id)

    q = q.order_by(desc(CustomScanner.created_at))
    result = await db.execute(q)
    user_scanners = [ScannerOut.model_validate(s) for s in result.scalars().all()]

    # Append popular system default scanners directly in the API
    system_scanners = []
    if include_public:
        for s_name, s_desc, s_cond, s_uuid in SYSTEM_SCANS:
            system_scanners.append(ScannerOut(
                id=uuid.UUID(s_uuid),
                user_id=user.id,
                name=s_name,
                description=s_desc,
                conditions=json.loads(s_cond),
                logic="AND",
                is_public=True,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            ))

    # To avoid duplicates if they were somehow seeded in the DB
    existing_names = {s.name for s in user_scanners}
    filtered_system_scanners = [s for s in system_scanners if s.name not in existing_names]

    return filtered_system_scanners + user_scanners


@router.post("/", response_model=ScannerOut, status_code=201)
async def create_scanner(
    body: ScannerCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Create a new custom scanner."""
    scanner = CustomScanner(
        user_id=user.id,
        name=body.name,
        description=body.description,
        conditions=[c.model_dump() for c in body.conditions],
        logic=body.logic,
        is_public=body.is_public,
    )
    db.add(scanner)
    await db.flush()
    return ScannerOut.model_validate(scanner)


@router.get("/{scanner_id}", response_model=ScannerOut)
async def get_scanner(
    scanner_id: UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Get a specific scanner by ID."""
    # Check if it's a system scan
    for s_name, s_desc, s_cond, s_uuid in SYSTEM_SCANS:
        if str(scanner_id) == s_uuid:
            return ScannerOut(
                id=uuid.UUID(s_uuid),
                user_id=user.id,
                name=s_name,
                description=s_desc,
                conditions=json.loads(s_cond),
                logic="AND",
                is_public=True,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )

    result = await db.execute(
        select(CustomScanner).where(CustomScanner.id == scanner_id)
    )
    scanner = result.scalar_one_or_none()
    if not scanner:
        raise HTTPException(status_code=404, detail="Scanner not found")
    if scanner.user_id != user.id and not scanner.is_public:
        raise HTTPException(status_code=403, detail="Not authorized")
    return ScannerOut.model_validate(scanner)


@router.put("/{scanner_id}", response_model=ScannerOut)
async def update_scanner(
    scanner_id: UUID,
    body: ScannerCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Update an existing scanner."""
    result = await db.execute(
        select(CustomScanner).where(
            CustomScanner.id == scanner_id, CustomScanner.user_id == user.id
        )
    )
    scanner = result.scalar_one_or_none()
    if not scanner:
        raise HTTPException(status_code=404, detail="Scanner not found or not owned by you")

    scanner.name = body.name
    scanner.description = body.description
    scanner.conditions = [c.model_dump() for c in body.conditions]
    scanner.logic = body.logic
    scanner.is_public = body.is_public
    await db.flush()
    return ScannerOut.model_validate(scanner)


@router.delete("/{scanner_id}", status_code=204)
async def delete_scanner(
    scanner_id: UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Delete a scanner."""
    result = await db.execute(
        select(CustomScanner).where(
            CustomScanner.id == scanner_id, CustomScanner.user_id == user.id
        )
    )
    scanner = result.scalar_one_or_none()
    if not scanner:
        raise HTTPException(status_code=404, detail="Scanner not found")
    await db.delete(scanner)


@router.post("/{scanner_id}/run")
async def run_scanner_endpoint(
    scanner_id: UUID,
    limit: int = Query(50, le=200),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Execute a scanner and return matching symbols."""
    import pandas as pd
    from app.services.scanner_engine import run_scanner

    class MockScanner:
        pass

    scanner = None
    # Check if it's a system scan
    for s_name, s_desc, s_cond, s_uuid in SYSTEM_SCANS:
        if str(scanner_id) == s_uuid:
            scanner = MockScanner()
            scanner.conditions = json.loads(s_cond)
            scanner.logic = "AND"
            break

    if not scanner:
        result = await db.execute(
            select(CustomScanner).where(CustomScanner.id == scanner_id)
        )
        scanner = result.scalar_one_or_none()

    if not scanner:
        raise HTTPException(status_code=404, detail="Scanner not found")

    # Get all active instruments
    from app.models import Instrument, OhlcvEod
    from sqlalchemy import text as sql_text

    instruments = (await db.execute(
        select(Instrument).where(Instrument.is_active == True).limit(500)
    )).scalars().all()

    matches = []
    for instr in instruments:
        rows = (await db.execute(
            select(OhlcvEod).where(
                (OhlcvEod.instrument_id == instr.id) &
                (OhlcvEod.open.is_not(None)) &
                (OhlcvEod.high.is_not(None)) &
                (OhlcvEod.low.is_not(None)) &
                (OhlcvEod.close.is_not(None))
            ).order_by(OhlcvEod.time.desc()).limit(100)
        )).scalars().all()

        if len(rows) < 20:
            continue

        df = pd.DataFrame([{
            "time": r.time,
            "open": float(r.open),
            "high": float(r.high),
            "low": float(r.low),
            "close": float(r.close),
            "volume": int(r.volume or 0),
        } for r in reversed(rows)])

        conditions = scanner.conditions
        logic = scanner.logic

        if run_scanner(df, conditions, logic):
            matches.append({
                "symbol": instr.symbol,
                "name": instr.name,
                "close": float(df.iloc[-1]["close"]),
                "volume": int(df.iloc[-1]["volume"]),
            })

        if len(matches) >= limit:
            break

    return {"scanner_id": str(scanner_id), "matches": matches, "count": len(matches)}
