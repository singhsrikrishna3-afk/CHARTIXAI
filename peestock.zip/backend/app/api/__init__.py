"""PEESTOCK — API route registrations."""
